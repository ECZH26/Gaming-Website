<!DOCTYPE html>
<html lang="en">

<head>  
  <?php //I have no clue what the code below does. The video didn't explain it. ?>

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,
  initial-scale=1.0">
  <title>Document</title>
</head>

<!-- <body>
  <?php //The code below is the example of php can be used within html line?>  
  <p>This is a <?php echo "awesome" ?> paragraph!</p>
  <?php echo "This is ALSO a paragraph!";?>
</body> -->

<!-- <body>
  <?php
    // You don't need to declare the variable type.
    $name = "Eric Huang";
    $num = 12343;
    $decnum =12.32;
    $con = True;

    $arr = array("one", "two", "three");
  ?>
  
  <p> Hi! My name is  <?php echo $name; ?>, and I'm learning PHP! </p>
</body> -->

<!-- <body>
  <?php
    // These are all server stuff
    echo $_SERVER["DOCUMENT_ROOT"];
    echo "<br>";
    echo $_SERVER["PHP_SELF"];
    echo "<br>";
    echo $_SERVER["SERVER_NAME"];
    echo "<br>";
    echo $_SERVER["REQUEST_METHOD"];

    // This pulls/get value from the website
    echo $_GET["name"];
    echo $_GET["eyecolor"];

    // It looks for value in all place. This very broad and not good for big data.
    echo $_REQUEST[""];

    // This is how we get the file that was sumbited/
    echo $_FILES[""];

    // It pulls/get cookie
    echo $_COOKIE[""];

    // When you open a value is assigned to the session and can be pulled.
    $_SESSION["username"] = "Krossing";
    echo $_SESSION["username"];

    // Data that is only for the admin
    $_ENV[""];
  ?>
</body> -->




</html>
